"""A Python library for creating the Open Australian Legal Corpus."""

from .creator import Creator
from .scraper import Scraper